// Products: SKU never reused, price history, stock only through movements.
import { fail } from './errors.js';
import { parseScaled, parsePrice, parseQty } from './money.js';
import { audit, applyMovement } from './post.js';

const nameKey = (s) => String(s).trim().toLowerCase();
// sale price: max 2 decimals (like the database column)
const parseSalePrice = (v, label) => parseScaled(v, 2, label) * 100;

async function nextSku(tx) {
  const used = new Set((await tx.all('sku_registry')).map(r => r.sku));
  let n = 1; while (used.has(n)) n++;
  return n;
}
async function reserveSku(ctx, tx, sku, productId) {
  const r = await tx.get('sku_registry', sku);
  if (r && r.product_id !== productId) fail('SKU_TAKEN', `SKU ${sku} already belongs to another product`, { sku });
  if (!r) await tx.insert('sku_registry', { sku, product_id: productId });
}
async function assertNameFree(tx, name, exceptId) {
  const dup = (await tx.find('products', p => !p.deleted_at && nameKey(p.name) === nameKey(name) && p.id !== exceptId))[0];
  if (dup) fail('PRODUCT_EXISTS', 'هذا المنتج موجود', { sku: dup.sku, name: dup.name });
}

export function productsApi(ctx) {
  const { store } = ctx;
  return {
    async create({ name, purchasePrice = 0, salePrice = 0, sku, qty = 0 }) {
      ctx.access.require('add_product');
      const q = parseQty(qty, 'qty');
      if (q > 0) ctx.access.require('manage_stock');          // initial stock = owner job by default
      return store.transaction(async (tx) => {
        if (!name || !String(name).trim()) fail('NAME_REQUIRED', 'Product name is required');
        await assertNameFree(tx, name);
        const wanted = sku == null ? await nextSku(tx) : Number(sku);
        if (!Number.isInteger(wanted) || wanted <= 0) fail('BAD_SKU', 'SKU must be a positive integer');
        if ((await tx.find('products', p => p.sku === wanted))[0]) fail('SKU_TAKEN', `SKU ${wanted} is used`, { sku: wanted });
        const t = ctx.now().toISOString();
        const p = await tx.insert('products', { id: ctx.ids(), sku: wanted, name: String(name).trim(),
          purchase_price: parsePrice(purchasePrice, 'purchase price'), sale_price: parseSalePrice(salePrice, 'sale price'),
          qty: 0, deleted_at: null, origin_device: ctx.deviceId ?? null, created_at: t, updated_at: t });
        await reserveSku(ctx, tx, wanted, p.id);
        await audit(ctx, tx, 'insert', 'products', p.id, null, p);
        if (q > 0) await applyMovement(ctx, tx, { product_id: p.id, reason: 'initial', qty_delta: q, unit_cost: p.purchase_price });
        return tx.get('products', p.id);
      });
    },

    // prices and name: every change is journaled; SKU change / delete need manage_stock
    async update(id, { name, purchasePrice, salePrice, sku }) {
      return store.transaction(async (tx) => {
        const p = await tx.get('products', id);
        if (!p || p.deleted_at) fail('UNKNOWN_PRODUCT', 'Unknown product');
        const patch = {};
        if (name !== undefined) { await assertNameFree(tx, name, id); patch.name = String(name).trim(); }
        if (purchasePrice !== undefined) { ctx.access.require('edit_purchase_price'); patch.purchase_price = parsePrice(purchasePrice, 'purchase price'); }
        if (salePrice !== undefined) { ctx.access.require('edit_sale_price'); patch.sale_price = parseSalePrice(salePrice, 'sale price'); }
        if (sku !== undefined && Number(sku) !== p.sku) {
          ctx.access.require('manage_stock');
          const n = Number(sku);
          if (!Number.isInteger(n) || n <= 0) fail('BAD_SKU', 'SKU must be a positive integer');
          if ((await tx.find('products', x => x.sku === n && x.id !== id))[0]) fail('SKU_TAKEN', `SKU ${n} is used`, { sku: n });
          await reserveSku(ctx, tx, n, id);
          patch.sku = n;
        }
        if (!Object.keys(patch).length) return p;
        patch.updated_at = ctx.now().toISOString();
        const u = await tx.update('products', id, patch);
        if ((patch.purchase_price ?? p.purchase_price) !== p.purchase_price || (patch.sale_price ?? p.sale_price) !== p.sale_price) {
          await tx.insert('price_history', { id: ctx.ids(), product_id: id, old_purchase_price: p.purchase_price,
            new_purchase_price: u.purchase_price, old_sale_price: p.sale_price, new_sale_price: u.sale_price,
            changed_by: ctx.userId ?? null, changed_at: ctx.now().toISOString() });
        }
        await audit(ctx, tx, 'update', 'products', id, p, u);
        return u;
      });
    },

    async remove(id) {                                         // soft delete: the SKU stays reserved
      ctx.access.require('manage_stock');
      return store.transaction(async (tx) => {
        const p = await tx.get('products', id);
        if (!p || p.deleted_at) fail('UNKNOWN_PRODUCT', 'Unknown product');
        const u = await tx.update('products', id, { deleted_at: ctx.now().toISOString(), updated_at: ctx.now().toISOString() });
        await audit(ctx, tx, 'update', 'products', id, p, u);
      });
    },

    // manual correction of the quantity (damage, inventory count): journaled movement
    async adjustStock(id, delta, reason = 'adjustment') {
      ctx.access.require('manage_stock');
      if (!['adjustment', 'damage'].includes(reason)) fail('BAD_REASON', 'Reason must be adjustment or damage');
      const d = Number(delta) < 0 ? -parseQty(String(delta).replace('-', '')) : parseQty(delta);
      if (d === 0) fail('BAD_NUMBER', 'Nothing to adjust');
      return store.transaction(async (tx) => applyMovement(ctx, tx, { product_id: id, reason, qty_delta: d }));
    },

    // import rows (CSV / paste): blank lines ignored, same name or SKU twice -> one line kept,
    // empty prices/qty -> 0, existing products are reported, never duplicated
    async import(rows) {
      ctx.access.require('manage_stock');
      return store.transaction(async (tx) => {
        const seenNames = new Set(), seenSkus = new Set();
        const report = { created: 0, skipped: [] };
        for (const r of rows) {
          const name = String(r.name ?? '').trim();
          if (!name) continue;
          const sku = r.sku === undefined || r.sku === '' || r.sku === null ? null : Number(r.sku);
          if (seenNames.has(nameKey(name)) || (sku && seenSkus.has(sku))) { report.skipped.push({ name, reason: 'duplicate_in_file' }); continue; }
          seenNames.add(nameKey(name)); if (sku) seenSkus.add(sku);
          if ((await tx.find('products', p => !p.deleted_at && nameKey(p.name) === nameKey(name)))[0]) { report.skipped.push({ name, reason: 'exists' }); continue; }
          if (sku && (await tx.find('products', p => p.sku === sku))[0]) { report.skipped.push({ name, reason: 'sku_taken' }); continue; }
          const wanted = sku || await nextSku(tx);
          const t = ctx.now().toISOString();
          const cost = parsePrice(r.purchasePrice ?? 0, 'purchase price');
          const p = await tx.insert('products', { id: ctx.ids(), sku: wanted, name, purchase_price: cost,
            sale_price: parseSalePrice(r.salePrice ?? 0, 'sale price'), qty: 0, deleted_at: null,
            origin_device: ctx.deviceId ?? null, created_at: t, updated_at: t });
          await reserveSku(ctx, tx, wanted, p.id);
          const q = parseQty(r.qty ?? 0, 'qty');
          if (q > 0) await applyMovement(ctx, tx, { product_id: p.id, reason: 'import', qty_delta: q, unit_cost: cost });
          report.created++;
        }
        await audit(ctx, tx, 'import', 'products', null, null, { created: report.created, skipped: report.skipped.length });
        return report;
      });
    },

    // search: digits = SKU only, letters = name only
    async search(text, limit = 30) {
      ctx.access.require('view_stock');
      const q = String(text ?? '').trim().toLowerCase();
      return store.transaction(async (tx) => {
        const all = (await tx.find('products', p => !p.deleted_at));
        const hit = !q ? all : /^\d+$/.test(q) ? all.filter(p => String(p.sku).startsWith(q)) : all.filter(p => p.name.toLowerCase().includes(q));
        return hit.sort((a, b) => a.sku - b.sku).slice(0, limit);
      });
    },
  };
}
